<?php
header('Content-type: text/css');
$c = (int) $_REQUEST['c'];
$view = isset($_REQUEST['view']) ? $_REQUEST['view'] : 'form';
echo "

.fabrikGroup {
clear: left;
}

/* missing from some bootstrap templates (like JoomlArt) */

.row-fluid:before,
.row-fluid:after {
	display: table;
	content: \"\";
	line-height: 0;
}

.row-fluid:after {
	clear: both;
}

.form-horizontal .control-label {
    color: #66727D;
    font-weight: bold;
    text-align: left !important;
    border-bottom: 1px dotted #ddd;
}
";
?>